# Build on Windows

Extract this folder outside the original pnpm workspace. Open Command Prompt here and run:

```bat
npm install --registry=https://registry.npmjs.org
npx eas-cli@latest build --platform android --profile preview
```

Use `com.motors915.mobile` and reuse the existing remote Android keystore.
