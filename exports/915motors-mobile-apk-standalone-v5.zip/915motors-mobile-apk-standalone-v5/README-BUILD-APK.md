# Build the 915motors Android APK

Extract this standalone Expo app outside the original Shop-Manager-Pro workspace, for example `C:\Users\915mo\Downloads\915motors-mobile-apk-v5`.

```bat
npm install --registry=https://registry.npmjs.org
npx eas-cli@latest build --platform android --profile preview
```

Use Android package ID `com.motors915.mobile` and reuse the existing remote Android keystore. The Web App tab is embedded in the app and keeps normal WebView caching enabled; native Invoices and Square payments remain available.
