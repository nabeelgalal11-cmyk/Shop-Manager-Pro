# Build the 915motors Android APK

This bundle is standalone and does not require the original monorepo. It intentionally has no lockfile because lockfiles created inside Replit can contain Replit-only registry URLs.

## 1. Install dependencies

From this folder:

```bat
npm install --registry=https://registry.npmjs.org
```

## 2. Build with EAS

```bat
npx eas-cli@latest build --platform android --profile preview
```

If EAS asks for the Android application ID, enter:

```text
com.motors915.mobile
```

Use the existing remote Android keystore when available. Do not generate a new keystore unless you intentionally want a new Square certificate fingerprint.

## 3. Download the APK

Open the build URL printed by EAS after the build completes and download the Android APK.
