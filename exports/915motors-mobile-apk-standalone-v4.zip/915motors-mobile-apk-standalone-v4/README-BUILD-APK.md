# Build the 915motors Android APK

This is a standalone Expo app bundle. Extract this folder outside the original Shop-Manager-Pro workspace, such as directly under `C:\Users\915mo\Downloads\915motors-mobile-apk-v4`.

## Install dependencies

From this folder:

```bat
npm install --registry=https://registry.npmjs.org
```

## Build with EAS

```bat
npx eas-cli@latest build --platform android --profile preview
```

If EAS asks for the Android application ID, enter:

```text
com.motors915.mobile
```

The Web App tab opens the complete web app inside the mobile app using an embedded WebView. The native Invoices tab remains available in the bottom bar for invoice lookup and Square payments.

Use the existing remote Android keystore when available. Do not generate a new keystore unless you intentionally want a new Square certificate fingerprint.
