# Build on Windows

1. Extract this folder outside the original pnpm workspace. Do not place it under `Shop-Manager-Pro-main`.
2. Open Command Prompt in this folder.
3. Run:

```bat
npm install --registry=https://registry.npmjs.org
npx eas-cli@latest build --platform android --profile preview
```

Use `com.motors915.mobile` as the Android application ID and reuse the existing remote Android keystore.
