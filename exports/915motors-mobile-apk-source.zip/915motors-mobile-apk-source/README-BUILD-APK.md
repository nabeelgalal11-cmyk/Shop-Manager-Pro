# 915motors Mobile APK Source

This is the minimum pnpm workspace needed to build the 915motors Android APK.

1. Install Node.js and pnpm.
2. Run `pnpm install` from this folder.
3. Run `cd artifacts/915motors-mobile`.
4. Run `npx eas-cli@latest login`.
5. Run `npx eas-cli@latest build -p android --profile preview`.

The preview profile produces an installable APK. The Android package name is
`com.motors915.mobile`. See `artifacts/915motors-mobile/BUILD-APK-ON-PC.md`
for Square fingerprint and production-profile details.
